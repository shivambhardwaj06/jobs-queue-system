import { Worker } from "bullmq";
import redisConnection from "../config/redis.js";
import pool from "../config/db.js";
import { ApiError } from "../utils/apiError.js";

const worker = new Worker(
    "job-queue",

async (job) => {

    console.log("Processing job:", job.id);
    console.log("Job type:", job.name);

    await pool.query(
        `UPDATE jobs
         SET status = 'processing',
             updated_at = NOW()
         WHERE id = $1`,
        [job.data.jobId]
    );

    if (job.name === "fail_test") {
        throw new ApiError("Simulated job failure");
    }

    await new Promise((resolve) => setTimeout(resolve, 2000));

    await pool.query(
        `UPDATE jobs
         SET status = 'completed',
             result = $1,
             completed_at = NOW(),
             updated_at = NOW()
         WHERE id = $2`,
        [
            JSON.stringify({
                message: "Job processed successfully"
            }),
            job.data.jobId
        ]
    );

    console.log("Job completed:", job.id);
},

    {
        connection: redisConnection,
    }
);

worker.on("failed", (job, error) => {
    console.log("Job failed:", job?.id);
    console.log("Reason:", error.message);
});