import pool from "../config/db.js";
import { asyncHandler } from "../utils/asyncHandler.js";
import { jobQueue } from "../queues/job.queue.js";

export const createJob = asyncHandler( async (req, res) => {
    try {
        const {
            type,
            payload,
            priority,
            maxAttempts
        } = req.body;

        // type is required field
        if (!type) {
            return res.status(400).json({
                success: false,
                message: "Job type is required",
            });
        }

        const result = await pool.query(
            `INSERT INTO jobs
            (type, payload, priority, max_attempts)
            VALUES ($1, $2, $3, $4)
            RETURNING *`,
            [
                type,
                payload || {},
                priority ?? 0,
                maxAttempts ?? 3,
            ]
        );
        const job = result.rows[0];
        await jobQueue.add(
            job.type,{
                jobId:job.id,
                type:job.type,
                payload:job.payload
            }
        )

        return res.status(201).json({
            success: true,
            message: "Job created and added to queue",
            job: result.rows[0],
        });

    } catch (error) {
        console.error("Create job error:", error);

        return res.status(500).json({
            success: false,
            message: "Failed to create job",
        });
    }
});